const axios = require('axios')

const sendResponse = async (responseUrl, answer) => {

  let text

  if (answer === 'approve') {
    text = "You've approved this request ✅"
  } else if (answer === 'deny') {
    text = "You've denied this request ❌"
  }

  const response = await axios.post(
		responseUrl,
		{
			replace_original: "true",
			text,
			headers: {
				'content-type': 'application/json',
				Authorization: `Bearer ${process.env.SLACK_BOT_USER_OAUTH_ACCESS_TOKEN}`,
			},
		}
	)
	return response
}

const authenticate = (httpMethod, token) => {
	if (httpMethod !== 'POST') {
		throw new Error('405')
	}
	const { SLACK_TOKEN } = process.env
	if (!token || token !== SLACK_TOKEN) {
		throw new Error('401')
	}
	console.log('Authentication successful')
}

exports.handler = async function (event, context, callback) {
  if (event) {
    const decodedMessage = decodeURIComponent(event.body);
    const messageObjectString = decodedMessage.split('payload=')[1]
    const messageObject = JSON.parse(messageObjectString)

    console.log(messageObject.message.text)

    const { token, response_url, actions } = messageObject

    authenticate('POST', token)

    const approverResponse = actions[0].value

    const response = await sendResponse(response_url, approverResponse)

    console.log(response.data)

    return {
			statusCode: 200,
			body: 'Cheers 🍻',
		}

  } else {
    console.log("No event")
    // Use this to retrigger a slack message to approver 
  }

}
